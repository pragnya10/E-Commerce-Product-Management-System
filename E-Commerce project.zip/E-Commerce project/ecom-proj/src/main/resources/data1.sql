INSERT INTO product (name, desc, brand, price, category, release_date, available, quantity) VALUES
                    ('iPhone 15', 'Apple smartphone with A16 Bionic chip and 48MP camera.', 'Apple', 79999.00, 'Mobiles', '2024-01-15', true, 25),
                    ('Samsung Galaxy S24', 'Flagship Android phone with dynamic AMOLED display and powerful performance.', 'Samsung', 74999.00, 'Mobiles', '2024-02-10', true, 30),
                    ('OnePlus 12', 'Premium smartphone with Snapdragon processor and fast charging.', 'OnePlus', 64999.00, 'Mobiles', '2024-03-05', true, 20),
                    ('Xiaomi 14', 'High-performance phone with sleek design and excellent camera setup.', 'Xiaomi', 59999.00, 'Mobiles', '2024-03-20', true, 35),
                    ('Google Pixel 8', 'Google smartphone with advanced AI camera features and clean Android experience.', 'Google', 68999.00, 'Mobiles', '2024-04-01', true, 18),
                    ('Realme GT 6', 'Fast and stylish mobile with gaming-focused performance.', 'Realme', 42999.00, 'Mobiles', '2024-04-18', true, 40),
                    ('Vivo X100', 'Camera-centric smartphone with premium build and smooth display.', 'Vivo', 57999.00, 'Mobiles', '2024-05-02', true, 22),
                    ('Oppo Reno 11', 'Mid-range smartphone with elegant design and balanced features.', 'Oppo', 38999.00, 'Mobiles', '2024-05-25', true, 28);
